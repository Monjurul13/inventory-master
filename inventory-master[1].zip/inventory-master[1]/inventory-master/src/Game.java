public class Game extends StockableProduct{
    private String developer;

    public Game(String developer) {
        this.developer =  developer;
    }

    public String getInfo() {
        return getDeveloper();
    }

    @Override
    public String toString() {
        return "Game{" +
                "developer='" + developer + '\'' +
                "} " + super.toString();
    }

    public String getDeveloper() {
        return developer;
    }

    public void setDeveloper(String developer) {
        this.developer = developer;
    }

}
