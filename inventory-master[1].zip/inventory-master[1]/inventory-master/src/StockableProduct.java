import java.io.Serializable;
import java.util.Objects;

public class StockableProduct extends Product implements Stockable {

    private int numberOfItemStock = 0;
    public StockableProduct() {}


    public StockableProduct(int id, String name, String genre, int quantity, int year, double discount, double price) {
        super.setProductId(id);
        super.setName(name);
        super.setDiscount(discount);
        super.setGenre(genre);
        super.setPrice(price);
        super.setYearPublished(year);
        addStock(quantity);
    }

    @Override
    String getInfo() {
        return null;
    }

    @Override
    public void addStock(int num) {
        this.numberOfItemStock += num;
    }


    @Override
    public void removeStock(int num) {
        this.numberOfItemStock -= num;
    }

    @Override
    public void editStock(int num) {}

    public int getNumberOfItemStock() {
        return numberOfItemStock;
    }

    public void setNumberOfItemStock(int numberOfItemStock) {
        this.numberOfItemStock = numberOfItemStock;
    }
}
