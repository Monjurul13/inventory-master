import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Objects;

public class InventoryFrame implements ActionListener {
    ArrayList<StockableProduct> items = new ArrayList<>();
    JFrame frame;
    JPanel panel1, panel2, panel3;
    JLabel productId, productName, productGenre, productPrice, productQuantity, productYear, productDiscount, deleteLabel, makeProductStockLabel, quantityLabel,makeInvoiceLabel, sortLabel;
    JTextField productIdField, productNameField, productPriceField, productQuantityField, productYearField, productDiscountField, deleteTextField, makeProductStockField, quantityField;
    JTextArea textArea;

    JComboBox cb;

    JButton addStock, sortByPriceButton, sortByStockButton, deleteButton,  makeProductStockButton, invoiceButton, viewListButton, gameButton,musicButton, movieButton, findChep;
    public InventoryFrame() {
        frame = new JFrame("Inventory");
        frame.setSize(900,700);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);

        panel1 = new JPanel();
        panel1.setLayout(null);
        panel1.setBounds(0,0,450,400);
        panel1.setBackground(new Color(245, 216, 216));


        productId = new JLabel("Product id: ");
        productId.setBounds(10,10, 200,30);

        productIdField = new JTextField();
        productIdField.setBounds(210, 10, 200, 30);

        productName = new JLabel("Product Name: ");
        productName.setBounds(10,40, 200,30);

        productNameField = new JTextField();
        productNameField.setBounds(210,40, 200,30);

        productGenre = new JLabel("Product Genre: ");
        productGenre.setBounds(10,70, 200,30);
        String[] genre={"Game","Movie","Music"};
        cb = new JComboBox(genre);
        cb.setBounds(210,70, 200,30);

        productQuantity = new JLabel("Product Quantity: ");
        productQuantity.setBounds(10,100, 200,30);

        productQuantityField = new JTextField();
        productQuantityField.setBounds(210,100, 80,30);

        productYear = new JLabel("Published Year: ");
        productYear.setBounds(10,130, 200,30);

        productYearField = new JTextField();
        productYearField.setBounds(210,130, 200,30);

        productDiscount = new JLabel("Product Discount: ");
        productDiscount.setBounds(10,160, 200,30);

        productDiscountField = new JTextField();
        productDiscountField.setBounds(210,160, 200,30);

        productPrice = new JLabel("Product price: ");
        productPrice.setBounds(10,190, 200,30);

        productPriceField = new JTextField();
        productPriceField.setBounds(210,190, 200,30);


        addStock = new JButton("ADD");
        addStock.setFocusable(false);
        addStock.setBounds(10,300, 100,30);
        addStock.addActionListener(this);

        viewListButton = new JButton("View List");
        viewListButton.setBounds(10, 350, 100, 30);
        viewListButton.addActionListener(this);
        viewListButton.setFocusable(false);

        sortLabel = new JLabel("Sort:");
        sortLabel.setBounds(120, 350, 50, 30);
        panel1.add(sortLabel);

        findChep = new JButton("Find cheap");
        findChep .setBounds(180, 300, 150, 30);
        findChep.setFocusable(false);
        findChep.addActionListener(this);
        panel1.add(findChep);


        gameButton = new JButton("Game");
        gameButton.setBounds(180, 350, 80, 30);
        gameButton.addActionListener(this);
        gameButton.setFocusable(false);
        panel1.add(gameButton);

        musicButton = new JButton("Music");
        musicButton.setBounds(270, 350, 80, 30);
        musicButton.addActionListener(this);
        musicButton.setFocusable(false);
        panel1.add(musicButton);

        movieButton = new JButton("Movie");
        movieButton.setBounds(360, 350, 80, 30);
        movieButton.addActionListener(this);
        movieButton.setFocusable(false);
        panel1.add(movieButton);




        panel1.add(viewListButton);

        panel1.add(productId);
        panel1.add(productIdField);
        panel1.add(productName);
        panel1.add(productNameField);
        panel1.add(productGenre);
        panel1.add(cb);
        panel1.add(productPrice);
        panel1.add(productPriceField);
        panel1.add(productQuantity);
        panel1.add(productQuantityField);
        panel1.add(productYear);
        panel1.add(productYearField);
        panel1.add(productDiscount);
        panel1.add(productDiscountField);
        panel1.add(addStock);





        panel2 = new JPanel();
        panel2.setLayout(null);
        panel2.setBounds(450,0,450,400);
        panel2.setBackground(new Color(134, 133, 133));

        // Create buttons for sorting and deleting
        sortByPriceButton = new JButton("Sort by Price");
        sortByStockButton = new JButton("Sort by Stock");
        deleteLabel = new JLabel("Delete Product ID:");
        deleteTextField = new JTextField();
        deleteButton = new JButton("Delete");

// Set bounds for buttons and text fields
        sortByPriceButton.setBounds(10, 50, 150, 30);
        sortByPriceButton.addActionListener(this);
        sortByPriceButton.setFocusable(false);

        sortByStockButton.setBounds(10, 100, 150, 30);
        sortByStockButton.addActionListener(this);
        sortByStockButton.setFocusable(false);

        deleteLabel.setBounds(10, 150, 150, 30);
        deleteTextField.setBounds(130, 150, 100, 30);

        deleteButton.setBounds(320, 150, 80, 30);
        deleteButton.addActionListener(this);
        deleteButton.setFocusable(false);


        makeProductStockLabel = new JLabel("Product ID Stock:");
        makeProductStockLabel.setBounds(10, 200, 120, 30);

        makeProductStockField = new JTextField();
        makeProductStockField.setBounds(130, 200, 100, 30);

// Adding quantity label and field horizontally
        quantityLabel = new JLabel("Quantity:");
        quantityLabel.setBounds(240, 200, 70, 30);

        quantityField = new JTextField();
        quantityField.setBounds(300, 200, 30, 30);

        makeProductStockButton = new JButton("Add");
        makeProductStockButton.setBounds(340, 200, 80, 30);
        makeProductStockButton.addActionListener(this);
        makeProductStockButton.setFocusable(false);



        makeInvoiceLabel = new JLabel("Make Invoice");
        makeInvoiceLabel.setBounds(10, 250, 150, 30);
        panel2.add(makeInvoiceLabel);

        // Initialize invoice button
        invoiceButton = new JButton("Invoice");
        invoiceButton.setBounds(170, 250, 80, 30);
        invoiceButton.addActionListener(this);
        invoiceButton.setFocusable(false);
        panel2.add(invoiceButton);

        panel2.add(quantityLabel);
        panel2.add(quantityField);

        panel2.add(makeProductStockLabel);
        panel2.add(makeProductStockField);
        panel2.add(makeProductStockButton);

        panel2.add(sortByPriceButton);
        panel2.add(sortByStockButton);
        panel2.add(deleteLabel);
        panel2.add(deleteTextField);
        panel2.add(deleteButton);



        panel3 = new JPanel();
        panel3.setLayout(new BorderLayout()); // Use a layout manager for panel3

        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Roboto", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(textArea);
        panel3.add(scrollPane, BorderLayout.CENTER);

// Set the preferred size for panel3 (make sure it's larger than or equal to the JScrollPane's viewport size)
        panel3.setPreferredSize(new Dimension(900, 300));

// Create a JScrollPane and add panel3 to it
        JScrollPane mainScrollPane = new JScrollPane(panel3);
        mainScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        mainScrollPane.setBounds(0, 400, 900, 300); // Set bounds for the main JScrollPane

        frame.add(mainScrollPane); // Add the main JScrollPane to the frame
        frame.add(panel1);
        frame.add(panel2);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == addStock) {
            try {
                int id = Integer.parseInt(productIdField.getText());
                String name = productNameField.getText();
                String genre = (String) cb.getSelectedItem();
                int quantity = Integer.parseInt(productQuantityField.getText());
                int year = Integer.parseInt(productYearField.getText());
                double discount = Double.parseDouble(productDiscountField.getText());
                double price = Double.parseDouble(productPriceField.getText());

                addToStock(id, name, genre, quantity, year, discount, price);
            } catch (Exception err) {
                JOptionPane.showMessageDialog(frame, "Invalid input");
            }

        } else if (e.getSource() == sortByPriceButton) {
            setSortByPrice();
        } else if (e.getSource() == sortByStockButton) {
            setSortByStock();
        } else if (e.getSource() == deleteButton) {
            deleteItem();
        } else if (e.getSource() == makeProductStockButton) {
            addNumberToStock();
        } else if (e.getSource() == invoiceButton) {
            new Invoice(items);
        } else if (e.getSource() == viewListButton) {
            viewList();
        } else if (e.getSource() == gameButton) {
            viewGame();
        } else if (e.getSource() == movieButton) {
            viewMovie();
        } else if (e.getSource() == musicButton) {
            viewMusic();
        } else if (e.getSource() == findChep) {
            viewCheap();
        }
    }

    public void addToStock(int id, String name, String genre, int quantity, int year, double discount, double price) {
        StockableProduct stockableProduct = new StockableProduct(id, name, genre, quantity, year, discount, price);
        items.add(stockableProduct);
        Inventory inventory = new Inventory(items);
        inventory.print();

        String str = "";
        textArea.setText(str);
        for (StockableProduct item : items) {
            str += "ID: "+item.getProductId() + " ," +
                    "NAME: "+item.getName() + " ," +
                    "GENRE: "+item.getGenre() + " ," +
                    "PRICE: "+item.getPrice() + " ," +
                    "PUBLISHED YEAR: "+item.getYearPublished() + " ," +
                    "DISCOUNT: "+item.getDiscount() + " ," +
                    "STOCK: "+item.getNumberOfItemStock() + "\n";

        }
        textArea.setText(str);
    }

    public void setSortByPrice() {
        Inventory inventory = new Inventory(items);
        inventory.sortByPrice();
        String str = "";
        textArea.setText(str);
        for (StockableProduct item : items) {
            str += "ID: "+item.getProductId() + " ," +
                    "NAME: "+item.getName() + " ," +
                    "GENRE: "+item.getGenre() + " ," +
                    "PRICE: "+item.getPrice() + " ," +
                    "PUBLISHED YEAR: "+item.getYearPublished() + " ," +
                    "DISCOUNT: "+item.getDiscount() + " ," +
                    "STOCK: "+item.getNumberOfItemStock() + "\n";

        }
        textArea.setText(str);
    }

    public void setSortByStock() {
        Inventory inventory = new Inventory(items);
        inventory.sortByAvailableStock();
        String str = "";
        textArea.setText(str);
        for (StockableProduct item : items) {
            str += "ID: "+item.getProductId() + " ," +
                    "NAME: "+item.getName() + " ," +
                    "GENRE: "+item.getGenre() + " ," +
                    "PRICE: "+item.getPrice() + " ," +
                    "PUBLISHED YEAR: "+item.getYearPublished() + " ," +
                    "DISCOUNT: "+item.getDiscount() + " ," +
                    "STOCK: "+item.getNumberOfItemStock() + "\n";

        }
        textArea.setText(str);
    }

    public void deleteItem() {
        Inventory inventory = new Inventory(items);
        int deletedItem = Integer.parseInt(deleteTextField.getText());
        inventory.removeItem(deletedItem);
        String str = "";
        textArea.setText(str);
        for (StockableProduct item : items) {
            str += "ID: "+item.getProductId() + " ," +
                    "NAME: "+item.getName() + " ," +
                    "GENRE: "+item.getGenre() + " ," +
                    "PRICE: "+item.getPrice() + " ," +
                    "PUBLISHED YEAR: "+item.getYearPublished() + " ," +
                    "DISCOUNT: "+item.getDiscount() + " ," +
                    "STOCK: "+item.getNumberOfItemStock() + "\n";

        }
        textArea.setText(str);
    }

    public void addNumberToStock() {
        Inventory inventory = new Inventory(items);
        int id = Integer.parseInt(makeProductStockField.getText());
        int number = Integer.parseInt(quantityField.getText());
        inventory.addProductStock(id, number);
        String str = "";
        textArea.setText(str);
        for (StockableProduct item : items) {
            str += "ID: "+item.getProductId() + " ," +
                    "NAME: "+item.getName() + " ," +
                    "GENRE: "+item.getGenre() + " ," +
                    "PRICE: "+item.getPrice() + " ," +
                    "PUBLISHED YEAR: "+item.getYearPublished() + " ," +
                    "DISCOUNT: "+item.getDiscount() + " ," +
                    "STOCK: "+item.getNumberOfItemStock() + "\n";

        }
        textArea.setText(str);
    }

    public void viewList() {
        String str = "";
        textArea.setText(str);
        for (StockableProduct item : items) {
            str += "ID: "+item.getProductId() + " ," +
                    "NAME: "+item.getName() + " ," +
                    "GENRE: "+item.getGenre() + " ," +
                    "PRICE: "+item.getPrice() + " ," +
                    "PUBLISHED YEAR: "+item.getYearPublished() + " ," +
                    "DISCOUNT: "+item.getDiscount() + " ," +
                    "STOCK: "+item.getNumberOfItemStock() + "\n";

        }
        textArea.setText(str);
    }

    public void viewGame() {
        String str = "";
        textArea.setText(str);
        for(int i = 0; i < items.size(); i++) {
            if (Objects.equals(items.get(i).getGenre(), "Game")) {
                str += items.get(i).getName() + "\n";
            }
        }
        textArea.setText(str);
    }

    public void viewMovie() {
        String str = "";
        textArea.setText(str);
        for(int i = 0; i < items.size(); i++) {
            if (Objects.equals(items.get(i).getGenre(), "Movie")) {
                str += items.get(i).getName() + "\n";
            }
        }
        textArea.setText(str);
    }

    public void viewMusic() {
        String str = "";
        textArea.setText(str);
        for(int i = 0; i < items.size(); i++) {
            if (Objects.equals(items.get(i).getGenre(), "Music")) {
                str += items.get(i).getName() + "\n";
            }
        }
        textArea.setText(str);
    }

    public void viewCheap() {
        String str = "";
        textArea.setText(str);
        int minPriceIndex = 0;
        double minPrice = items.get(0).getPrice();
        for(int i = 0; i < items.size(); i++) {
            if(minPrice > items.get(i).getPrice()) {
                minPriceIndex = i;
                minPrice = items.get(i).getPrice();
            }
        }
        str +=  "Name: " + items.get(minPriceIndex).getName() + ", Price: " + items.get(minPriceIndex).getPrice()+ "\n";
        textArea.setText(str);
    }
}
