import java.util.ArrayList;
import java.util.Comparator;

public class Inventory {
    private ArrayList<StockableProduct> items;

    public Inventory() {}

    public Inventory(ArrayList<StockableProduct> items) {
        this.items = items;
    }

    public void addItem(StockableProduct product) {
        items.add(product);
    }

    public void removeItem(int productId) {
        for(int i = 0; i < items.size(); i++) {
            if(items.get(i).getProductId() == productId) {
                items.remove(i);
                break;
            }
        }
    }

    public Product getItem(int productId) {
        for(int i = 0; i < items.size(); i++) {
            if(items.get(i).getProductId() == productId) {
                return items.get(i);
            }
        }
        return null;
    }

    public void addProductStock(int productId, int numberOfNewStock) {
        for(int i = 0; i < items.size(); i++) {
            if(items.get(i).getProductId() == productId) {
                items.get(i).addStock(numberOfNewStock);
            }
        }
    }

    public void sortByPrice() {
        items.sort(Comparator.comparingDouble(StockableProduct::getPrice));
    }

    public void sortByAvailableStock() {
        items.sort(Comparator.comparingInt(StockableProduct::getNumberOfItemStock).reversed());
    }

    @Override
    public String toString() {
        return "Inventory{" +
                "items=" + items +
                '}';
    }

    public void print() {
        for(int i = 0; i < items.size(); i++) {
            System.out.println(items.get(i).getName());
        }
    }
}
