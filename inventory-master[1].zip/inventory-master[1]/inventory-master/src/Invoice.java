import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Objects;

public class Invoice implements ActionListener {
    ArrayList<StockableProduct> items;
    ArrayList<Product> itemsCart = new ArrayList<>();
    JFrame frame;
    JPanel topPanel;
    JPanel secondPanel;
    JLabel addProductIdLabel;
    JTextField addProductIdTextField;
    JButton addProductIdButton;
    JLabel removeProductIdLabel;
    JTextField removeProductIdTextField;
    JButton removeProductIdButton;
    JButton makeBillButton;
    JTextArea textArea;
    JScrollPane scrollPane;

    private LocalDateTime date;

    public Invoice(ArrayList<StockableProduct> items) {

        this.items = items;

        frame = new JFrame("Invoice");
        frame.setSize(500, 500);
        frame.setLayout(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Calculate panel sizes based on frame size
        int panelWidth = frame.getWidth();
        int panelHeight = frame.getHeight() / 2;

        // Create and configure topPanel
        topPanel = new JPanel();
        topPanel.setBounds(0, 0, panelWidth, panelHeight);
        topPanel.setLayout(null);
        frame.add(topPanel);

        // Initialize components
        addProductIdLabel = new JLabel("Add Product Id");
        addProductIdLabel.setBounds(20, 20, 150, 30);
        topPanel.add(addProductIdLabel);

        addProductIdTextField = new JTextField();
        addProductIdTextField.setBounds(180, 20, 150, 30);
        topPanel.add(addProductIdTextField);

        addProductIdButton = new JButton("Add");
        addProductIdButton.setBounds(340, 20, 80, 30);
        addProductIdButton.addActionListener(this);
        topPanel.add(addProductIdButton);

        removeProductIdLabel = new JLabel("Remove Product Id");
        removeProductIdLabel.setBounds(20, 60, 150, 30);
        topPanel.add(removeProductIdLabel);

        removeProductIdTextField = new JTextField();
        removeProductIdTextField.setBounds(180, 60, 150, 30);
        topPanel.add(removeProductIdTextField);

        removeProductIdButton = new JButton("Remove");
        removeProductIdButton.setBounds(340, 60, 80, 30);
        removeProductIdButton.addActionListener(this);
        topPanel.add(removeProductIdButton);


        // Add button for making the bill
        makeBillButton = new JButton("Make Bill");
        makeBillButton.setBounds(20, 140, 150, 30);
        makeBillButton.addActionListener(this);
        topPanel.add(makeBillButton);

        // Create and configure secondPanel
        // Create and configure secondPanel
        secondPanel = new JPanel();
        secondPanel.setBounds(0, panelHeight, panelWidth, panelHeight);
        secondPanel.setLayout(null);
        frame.add(secondPanel);

        // Initialize text area for the second panel
        textArea = new JTextArea();
        textArea.setFont(new Font("Roboto", Font.PLAIN, 18));
        // Create a scroll pane and add the text area to it
        scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(10, 0, panelWidth, panelHeight);
        secondPanel.add(scrollPane);

        frame.setVisible(true);
    }

    public String  getLocalDateTime() {
        LocalDateTime currentDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return currentDateTime.format(formatter);
    }

    public void addProduct() {
        int id = Integer.parseInt(addProductIdTextField.getText());
        for(int i = 0; i < items.size(); i++) {
            if(items.get(i).getProductId() == id) {
                itemsCart.add(items.get(i));
                items.get(i).removeStock(1);
                break;
            }
        }

        String str = "";
        for(int i = 0; i < itemsCart.size(); i++) {
            str += "Name: " + itemsCart.get(i).getName() + ",Price: " + itemsCart.get(i).getPrice() + "\n";
        }
        textArea.setText(str);
    }

    public void removeProduct() {
        int id = Integer.parseInt(addProductIdTextField.getText());
        for(int i = 0; i < items.size(); i++) {
            if(items.get(i).getProductId() == id) {
                itemsCart.remove(items.get(i));
                items.get(i).addStock(1);
                break;
            }
        }
        String str = "";
        for(int i = 0; i < itemsCart.size(); i++) {
            str += "Name: " + itemsCart.get(i).getName() + ",Price: " + itemsCart.get(i).getPrice() + "\n";
        }
        textArea.setText(str);
    }

    private double calculatePriceWithoutDiscount() {
        double price = 0.0;
        for(int i = 0; i < itemsCart.size(); i++) {
            price += itemsCart.get(i).getPrice();
        }
        return price;
    }

    private boolean isFullHouseDiscountAvailable() {
        int game = 0;
        int movie = 0;
        int music = 0;
        for (int i = 0; i < itemsCart.size(); i++) {
            if(Objects.equals(itemsCart.get(i).getGenre(), "Game")) {
                game++;
            } else if (Objects.equals(itemsCart.get(i).getGenre(), "Music")) {
                music++;
            }  else if (Objects.equals(itemsCart.get(i).getGenre(), "Movie")) {
                movie++;
            }
        }
        return (game >= 2 && movie >= 2 && music >= 2);
    }

    private double calculateDiscountPrice() {
        double discountPriceWithNormalPrice = 0.0;
        boolean isFullHouse = isFullHouseDiscountAvailable();
        double normalPrice = calculatePriceWithoutDiscount();
        double isFullHousePrice = normalPrice / 2.0;

        for(int i = 0; i < itemsCart.size(); i++) {
            discountPriceWithNormalPrice += (itemsCart.get(i).getPrice() - (itemsCart.get(i).getPrice() * ( itemsCart.get(i).getDiscount() / 100.0)));
        }

        return (isFullHouse) ?  isFullHousePrice: discountPriceWithNormalPrice;
    }

    public String getInvoice() {
        String str = getLocalDateTime() + "\n";
        for(int i = 0; i < itemsCart.size(); i++) {
            str += "Name: " + itemsCart.get(i).getName() + ",Price: " + itemsCart.get(i).getPrice() + "\n";
        }
        return str;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == addProductIdButton) {
            addProduct();
        } else if (e.getSource() == removeProductIdButton) {
            removeProduct();
        } else if (e.getSource() == makeBillButton) {
            double discountPrice = calculateDiscountPrice();
            double totalPrice = calculatePriceWithoutDiscount();
            String str = getInvoice();
            str += "Total Price: " + totalPrice + "\n" + "Price after discount: " + discountPrice + "\n\n\n";
            textArea.setText(str);
        }
    }
}
