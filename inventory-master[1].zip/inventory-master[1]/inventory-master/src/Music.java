public class Music extends StockableProduct{

    private String artistName;
    public Music(String author) {}

    public String getInfo() {
        return getArtistName();
    }

    public String getArtistName() {
        return artistName;
    }

    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }
}
