public class Movie extends StockableProduct{
    private String director;

    public Movie(String author) {}

    public String getInfo() {
        return getDirector();
    }

    @Override
    public String toString() {
        return "Movie{" +
                "director='" + director + '\'' +
                "} " + super.toString();
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }
}
